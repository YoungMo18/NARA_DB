package com.NARAHeritageLab.Server_side_NHRL_DB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServerSideNhrlDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServerSideNhrlDbApplication.class, args);
	}

}
